package ru.yooxa.ycore;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;

import java.util.HashMap;
import java.util.Map;

import net.md_5.bungee.protocol.DefinedPacket;
import net.md_5.bungee.protocol.ProtocolConstants;
import net.md_5.bungee.protocol.packet.Login;
import net.md_5.bungee.protocol.packet.extra.ChunkPacket;
import net.md_5.bungee.protocol.packet.extra.PlayerAbilities;
import net.md_5.bungee.protocol.packet.extra.PlayerPositionRotation;
import net.md_5.bungee.protocol.packet.extra.SetSlot;
import net.md_5.bungee.protocol.packet.extra.SpawnPosition;

public class Connection {

    public static int min;
    public static ByteBuf[] maps1_8;
    public static ByteBuf[] maps1_9;
    private static final Map<Integer, ByteBuf>  packets1_8 = new HashMap<Integer, ByteBuf>(4);
    private static final Map<Integer, ByteBuf>  packets1_9 = new HashMap<Integer, ByteBuf>(4);
    public static final Login login = new Login(-1, (short) 0, 0, (short) 0, (short) 100, "flat", false);
    public static final SpawnPosition spawnPosition = new SpawnPosition(5, 60, 5);
    public static final PlayerPositionRotation playerPosition = new PlayerPositionRotation(5.0D, 500.0D, 5.0D, 90.0F, 90.0F);
    public static final SetSlot setSlot = new SetSlot(0, 36, 358, 0);
    public static final ChunkPacket chunk1_9 = new ChunkPacket(0, 0);
    public static final PlayerAbilities abilities1_9 = new PlayerAbilities((byte) 6, 0.0F, 0.0F);

    public static ByteBuf getCaptcha(int captcha, int protocol) {
        return protocol > 47 ? Connection.maps1_9[captcha - Connection.min] : Connection.maps1_8[captcha - Connection.min];
    }

    public static ByteBuf getPacket(int id, int protocol) {
        if (id >= 1 && id <= 4) {
            Map<Integer, ByteBuf>  map = protocol > 47 ? Connection.packets1_9 : Connection.packets1_8;

            return (ByteBuf) map.get(Integer.valueOf(id));
        } else {
            throw new IllegalStateException();
        }
    }

    public static ByteBuf getBytes(DefinedPacket packet, int id, int protocol) throws Exception {
        ByteBuf buffer = ByteBufAllocator.DEFAULT.buffer();

        DefinedPacket.writeVarInt(id, buffer);
        packet.write(buffer, ProtocolConstants.Direction.TO_CLIENT, protocol);
        return buffer;
    }
}
