package ru.yooxa.ycore;

import java.lang.reflect.Method;

public class GenerateTask implements Runnable {

    private final Object generator;
    private Method generateMap;
    private Method increment;
    private final int n;

    public GenerateTask(Object generator, int n) {
        this.generator = generator;

        try {
            this.generateMap = generator.getClass().getMethod("generateMap", new Class[] { Integer.TYPE});
            this.increment = generator.getClass().getMethod("increment", new Class[0]);
        } catch (Exception exception) {
            exception.printStackTrace();
            System.exit(0);
        }
        this.n = n;
    }

    public void run() {
        try {
            this.generateMap.invoke(this.generator, new Object[] { Integer.valueOf(this.n)});
            this.increment.invoke(this.generator, new Object[0]);
        } catch (Exception exception) {
            exception.printStackTrace();
            System.exit(0);
        }

    }
}
