package ru.yooxa.bungee.connection;

import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.UserConnection;
import net.md_5.bungee.Util;
import net.md_5.bungee.api.Callback;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.connection.UpstreamBridge;
import net.md_5.bungee.netty.ChannelWrapper;
import net.md_5.bungee.netty.HandlerBoss;
import net.md_5.bungee.netty.PacketHandler;
import net.md_5.bungee.protocol.DefinedPacket;
import net.md_5.bungee.protocol.ProtocolConstants;
import net.md_5.bungee.protocol.packet.Chat;
import net.md_5.bungee.protocol.packet.ClientSettings;
import net.md_5.bungee.protocol.packet.KeepAlive;
import ru.yooxa.database.SqlStorage;
import ru.yooxa.ycore.Connection;

import com.google.common.base.Preconditions;

public class CaptchaBridge extends PacketHandler {

    private static final Random random = new Random();
    private static String TIMEOUT;
    private static String ENTER_CAPTCHA;
    private static String INVALID;
    private final UserConnection con;
    private boolean settings;
    private int captcha = getRandomCaptcha();
    private static Map<UserConnection, CaptchaBridge> connections = new ConcurrentHashMap<UserConnection, CaptchaBridge>();
    private static SqlStorage sql;
    private static AtomicInteger a = new AtomicInteger();
    private final long joinTime = System.currentTimeMillis();
    private int retrys = 3;

    public static void init() {
        CaptchaBridge.sql = new SqlStorage();
        CaptchaBridge.TIMEOUT = SqlStorage.messageTimeout;
        CaptchaBridge.ENTER_CAPTCHA = SqlStorage.messageEnter;
        CaptchaBridge.INVALID = SqlStorage.messageInvalid;

        try {
            CaptchaGenerator captchagenerator = new CaptchaGenerator();
            captchagenerator.generate(CaptchaBridge.sql.threads, SqlStorage.minCaptcha, SqlStorage.maxCaptcha);
        } catch (Exception exception) {
            System.out.println("Exception while generate maps");
            exception.printStackTrace();
            System.exit(0);
        }

    }

    public CaptchaBridge() {
        this.con = null;
    }

    public static int getOnline() {
        return CaptchaBridge.connections.size();
    }

    public UserConnection getCon() {
        return this.con;
    }

    public long getJoinTime() {
        return this.joinTime;
    }

    public CaptchaBridge(UserConnection connection) {
        this.con = connection;
        CaptchaBridge.a.incrementAndGet();
        this.connected();
    }

    private void connected() {
        int protocol = this.con.getPendingConnection().getHandshake().getProtocolVersion();
        Channel channel = this.con.getCh().getHandle();

        this.con.setClientEntityId(-1);
        byte id1;
        byte id2;
        byte id3;

        if (protocol > 47) {
            id1 = 35;
            id2 = 67;
            id3 = 46;
        } else {
            id1 = 1;
            id2 = 5;
            id3 = 8;
        }

        this.write(channel, Connection.login, protocol, id1);
        this.write(channel, Connection.spawnPosition, protocol, id2);
        if (protocol > 47) {
            this.write(channel, Connection.chunk1_9, protocol, 32);
            this.write(channel, Connection.setSlot, protocol, 22);
            this.write(channel, Connection.abilities1_9, protocol, 43);
        } else {
            this.write(channel, Connection.setSlot, protocol, 47);
        }

        this.write(channel, Connection.playerPosition, protocol, id3);
        this.resetCaptcha();
        CaptchaBridge.connections.put(this.con, this);

    }

    private void write(Channel channel, DefinedPacket packet, int protocol, int id) {
        ByteBuf buf = channel.alloc().buffer();

        DefinedPacket.writeVarInt(id, buf);
        packet.write(buf, ProtocolConstants.Direction.TO_CLIENT, protocol);
        channel.write(buf);
    }

    private void write(Channel channel, ByteBuf buf) {
        ByteBuf buffer = buf.copy();

        channel.write(buffer);
    }

    public void exception(Throwable t) throws Exception {
        if (!this.isBot()) {
            this.con.disconnect(Util.exception(t));
            this.con.getCh().close();
            BungeeCord.getInstance().removeConnection( this.con );
        } else {
            this.con.getCh().close();
            BungeeCord.getInstance().removeConnection( this.con );
        }

    }

    public void disconnected(ChannelWrapper channel) throws Exception {
        CaptchaBridge.connections.remove(this.con);
        BungeeCord.getInstance().getPluginManager().callEvent(new PlayerDisconnectEvent(this.con));
        BungeeCord.getInstance().removeConnection( this.con );
    }

    public void handle(KeepAlive alive) throws Exception {
        if (alive.getRandomId() == this.con.getSentPingId()) {
            int newPing = (int) (System.currentTimeMillis() - this.con.getSentPingTime());

            this.con.setPing(newPing);
        }
    }

    private void resetCaptcha() {
        int protocol = this.con.getPendingConnection().getHandshake().getProtocolVersion();
        Channel channel = this.con.getCh().getHandle();

        this.captcha = getRandomCaptcha();
        this.write(channel, Connection.getCaptcha(this.captcha, protocol));
        channel.flush();
    }

    private boolean isBot() {
        return !this.settings;
    }

    private static int getRandomCaptcha() {
        return CaptchaBridge.random.nextInt(CaptchaGenerator.max - CaptchaGenerator.min) + CaptchaGenerator.min;
    }

    public void handle(Chat chat) throws Exception {
        Preconditions.checkArgument(chat.getMessage().length() <= 100, "Chat message too long");
        if (this.isBot()) {
            this.con.sendMessage("[§cCaptcha§f] Введите номер с картинки.");
        } else {
            if (!chat.getMessage().equals(String.valueOf(this.captcha))) {
                if (--this.retrys == 0) {
                    this.con.disconnect("[§cCaptcha§f] Неверная капча");
                    this.con.getCh().close();
                } else {
                    this.resetCaptcha();
                    this.con.sendMessage(String.format(CaptchaBridge.INVALID, new Object[] { Integer.valueOf(this.retrys), this.retrys == 1 ? "а" : "и"}));
                }
            } else {
                this.finish();
            }

        }
    }

    private void finish() {
        this.con.serverr = true;
        ((HandlerBoss) this.con.getCh().getHandle().pipeline().get(HandlerBoss.class)).setHandler(new UpstreamBridge(ProxyServer.getInstance(), this.con));
        ProxyServer.getInstance().getPluginManager().callEvent(new PostLoginEvent(this.con));
        this.con.connect(ProxyServer.getInstance().getServerInfo(this.con.getPendingConnection().getListener().getDefaultServer()), (Callback<Boolean>) null, true);
        CaptchaBridge.sql.addIp(this.con.getAddress().getAddress().getHostAddress());
        CaptchaBridge.connections.remove(this.con);
    }

    public void handle(ClientSettings settings) throws Exception {
        this.settings = true;
        this.con.setSettings(settings);
    }

    public String toString() {
        return "§c[" + this.con.getName() + "] §7<-> §bCaptcha";
    }

    static {
        (new Thread(new Runnable() {
            public void run() {
                while (true) {
                    if (!Thread.interrupted()) {
                        try {
                            Thread.sleep(2500L);
                        } catch (InterruptedException interruptedexception) {
                            interruptedexception.printStackTrace();
                        }

                        long curr = System.currentTimeMillis();
                        Iterator<CaptchaBridge> iterator = CaptchaBridge.connections.values().iterator();
                        CaptchaBridge b;
                        while (iterator.hasNext()) {
                            b = (CaptchaBridge) iterator.next();
                            if (curr - b.getJoinTime() >= (long) SqlStorage.timeout) {
                                if (!b.isBot()) {
                                    b.getCon().disconnect(CaptchaBridge.TIMEOUT);
                                    b.getCon().getCh().close();
                                } else {
                                    b.getCon().getCh().close();
                                }
                                iterator.remove();
                            } else {
                                b.getCon().sendMessage(CaptchaBridge.ENTER_CAPTCHA);
                            }
                        }
                    }
                }
            }
        }, "Captcha TimeoutHandler")).start();
        (new Thread(new Runnable() {
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(5000L);
                    } catch (InterruptedException interruptedexception) {
                        interruptedexception.printStackTrace();
                    }
                    int i = CaptchaBridge.a.get();
                    if (i > 0) {
                        System.out.println("[Captcha] Подлючений в течении 5 секунд - " + i);
                    }
                    CaptchaBridge.a.set(0);
                }

            }
        }, "Captcha ConnectionsCounter")).start();
    }
}
