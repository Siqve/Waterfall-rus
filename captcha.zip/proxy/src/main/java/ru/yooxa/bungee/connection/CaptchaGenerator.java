package ru.yooxa.bungee.connection;

import com.github.cage.GCage;
import net.md_5.bungee.BungeeCord;
import io.netty.buffer.ByteBuf;
import java.awt.image.BufferedImage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import net.md_5.bungee.protocol.packet.extra.MapDataPacket;
import org.bukkit.map.CraftMapCanvas;
import org.bukkit.map.MapPalette;
import ru.yooxa.ycore.Connection;
import ru.yooxa.ycore.GenerateTask;

public class CaptchaGenerator {

    public static int min = 100;
    public static int max = 999;
    private AtomicInteger count = new AtomicInteger();
    private static final GCage localGCage = new GCage();

    public void generate(int threads, int min, int max) throws Exception {
        Connection.min = min;
        CaptchaGenerator.min = min;
        CaptchaGenerator.max = max;
        BungeeCord.getInstance().getLogger().info("§cГенерирую капчу");
        long start = System.currentTimeMillis();
        int all = max - min + 1;

        this.count.set(0);
        Connection.min = min;
        Connection.maps1_8 = new ByteBuf[all];
        Connection.maps1_9 = new ByteBuf[all];
        ExecutorService executor = Executors.newFixedThreadPool(threads);

        int i;

        for (i = min; i <= max; ++i) {
            executor.execute(new GenerateTask(this, i));
        }

        while ((i = this.count.get()) != all) {
            try {
                System.out.println(i + " из " + all + " [" + (int) ((double) i / (double) all * 100.0D) + " %]");
                Thread.sleep(1000L);
            } catch (InterruptedException interruptedexception) {
                return;
            }
        }

        executor.shutdown();
        System.out.println("Капча сгенерирована за (" + (System.currentTimeMillis() - start) + " мс)");
        start = System.currentTimeMillis();
        System.gc();
        System.out.println("Память очищена за (" + (System.currentTimeMillis() - start) + " мс)");
    }

    public void increment() {
        this.count.incrementAndGet();
    }

    public void generateMap(int captcha) {
        String s = String.valueOf(captcha);
        CraftMapCanvas map = new CraftMapCanvas();

        map.drawImage(0, 0, MapPalette.resizeImage(createCaptchaImage(s)));

        try {
            MapDataPacket ex = new MapDataPacket(0, (byte) 0, MapDataPacket.Type.IMAGE, map.getMapData());

            Connection.maps1_8[captcha - CaptchaGenerator.min] = Connection.getBytes(ex, 52, 47);
            Connection.maps1_9[captcha - CaptchaGenerator.min] = Connection.getBytes(ex, 36, 107);
        } catch (Exception exception) {
            System.out.println("Ошибка генерации картинок, сообщите разработчику - vk.com/leymooo_s");
            System.exit(0);
        }

    }

    public static BufferedImage createCaptchaImage(String paramString) {
        return CaptchaGenerator.localGCage.drawImage(paramString);
    }
}
