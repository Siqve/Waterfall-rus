package ru.yooxa.database;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;

public class SqlStorage {

    private static Set<String> ips = new HashSet<String>();
    public int threads;
    public static boolean Ripple;
    public static boolean Blur;
    public static boolean Outline;
    public static boolean Rotate;
    public static boolean connectionsLog;
    public static boolean captchaOnline;
    public static String motd;
    public static String messageTimeout;
    public static String messageEnter;
    public static String messageInvalid;
    public static int minCaptcha;
    public static int maxCaptcha;
    public static int timeout;

    public SqlStorage() {
        this.loadConfig();
    }

    public static boolean isWhite(String ip) {
        return SqlStorage.ips.contains(ip);
    }

    private void loadConfig() {
        File file = new File("captcha.yml");
        
        try {
            Configuration config;

            if (!file.exists()) {
                config = new Configuration();
                config.set("Image-Generation-Threads", Integer.valueOf(2));
                config.set("Log-Join", Boolean.valueOf(true));
                config.set("Timeout", Integer.valueOf(15000));
                config.set("Message-Timeout", "[§cCaptcha§f] Вы слишком долго вводили капчу");
                config.set("Message-Enter", "[§cCaptcha§f] Введите номер с картинки в чат, чтобы пройти проверку. Открыть чат кнопкой \"T\" (английская)");
                config.set("Message-Invalid", "[§cCaptcha§f] Неверная капча, у вас осталось §e%d§f попытк%s");
                config.set("Min-Captcha", Integer.valueOf(100));
                config.set("Mam-Captcha", Integer.valueOf(999));
                config.set("Map-options.Ripple", Boolean.valueOf(true));
                config.set("Map-options.Blur", Boolean.valueOf(true));
                config.set("Map-options.Outline", Boolean.valueOf(false));
                config.set("Map-options.Rotate", Boolean.valueOf(true));
                ConfigurationProvider.getProvider(YamlConfiguration.class).save(config, file);
                BungeeCord.getInstance().getLogger().warning("§c[CAPTCHA] §eЯ создал конфиг. Редактируй \'captcha.yml\'");
                BungeeCord.getInstance().getLogger().warning("§c[CAPTCHA] §aЗапуск через 5 сек'");
                Thread.sleep(5000l);
                file = new File("captcha.yml");
                if (!file.exists()) {
                    System.exit(0);
                    return;
                }
                config = ConfigurationProvider.getProvider(YamlConfiguration.class).load(file);
            } else {
                config = ConfigurationProvider.getProvider(YamlConfiguration.class).load(file);
                if (!config.contains("Map-options")) {
                    config.set("Map-options.Ripple", Boolean.valueOf(true));
                    config.set("Map-options.Blur", Boolean.valueOf(true));
                    config.set("Map-options.Outline", Boolean.valueOf(false));
                    config.set("Map-options.Rotate", Boolean.valueOf(true));
                    ConfigurationProvider.getProvider(YamlConfiguration.class).save(config, file);
                }
            }

            this.threads = config.getInt("Image-Generation-Threads");
            SqlStorage.timeout = config.getInt("Timeout");
            SqlStorage.connectionsLog = config.getBoolean("Log-Join");
            SqlStorage.messageTimeout = config.getString("Message-Timeout");
            SqlStorage.messageEnter = config.getString("Message-Enter");
            SqlStorage.messageInvalid = config.getString("Message-Invalid");
            SqlStorage.minCaptcha = config.getInt("Min-Captcha", 100);
            SqlStorage.maxCaptcha = config.getInt("Mam-Captcha", 999);
            SqlStorage.Ripple = config.getBoolean("Map-options.Ripple");
            SqlStorage.Blur = config.getBoolean("Map-options.Blur");
            SqlStorage.Outline = config.getBoolean("Map-options.Outline");
            SqlStorage.Rotate = config.getBoolean("Map-options.Rotate");

        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }

    public void addIp(String ip) {
        SqlStorage.ips.add(ip);
    }
}
